import React from "react";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-green-50 text-gray-800 font-sans">
      <header className="bg-green-700 text-white p-6 shadow-md">
        <h1 className="text-3xl font-bold">GoldenHarvestAcres</h1>
        <p className="text-sm">Rich farm</p>
      </header>

      <section className="p-8 text-center">
        <h2 className="text-2xl font-semibold mb-2">About Us</h2>
        <p className="max-w-xl mx-auto">
          To maximize crop yields and quality while delivering premium agricultural
          products to local and global markets.
        </p>
      </section>

      <section className="p-8 bg-white text-center">
        <h2 className="text-2xl font-semibold mb-4">Our Products</h2>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
          <li className="bg-green-100 p-4 rounded shadow">Palm Oil</li>
          <li className="bg-green-100 p-4 rounded shadow">Palm Kernel Oil</li>
          <li className="bg-green-100 p-4 rounded shadow">Animal Feed</li>
          <li className="bg-green-100 p-4 rounded shadow">Fresh Fruit Bunches</li>
        </ul>
      </section>

      <section className="p-8 text-center bg-green-100">
        <h2 className="text-2xl font-semibold mb-4">Contact Us</h2>
        <p>Email: <a href="mailto:goldenharvestacresltd@gmail.com" className="text-green-700 font-medium">goldenharvestacresltd@gmail.com</a></p>
        <p>WhatsApp: <a href="https://wa.me/2347051493342" className="text-green-700 font-medium">+2347051493342</a></p>
      </section>

      <footer className="bg-green-700 text-white text-center p-4">
        <p>&copy; {new Date().getFullYear()} GoldenHarvestAcres. All rights reserved.</p>
        <p>www.goldenharvestacres.com</p>
      </footer>
    </main>
  );
}
